# Example Package

This is a repository to track who fails more often at pre-commits!